To compile:
run the make command then do ./buffer